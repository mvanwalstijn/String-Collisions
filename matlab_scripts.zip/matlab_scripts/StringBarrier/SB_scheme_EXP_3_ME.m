% scheme EXP-3-ME (string-barrier)
% Maarten van Walstijn 2023
function[output,t,dt,TIM] = scheme_EXP_3_ME(par,Fs,F_record,F_plot)

V0 = eps;           % the energy gauge need not be more than the machine epsilon
OF = Fs/44100;      % the oversampling factor (w.r.t. 44.1 kHz)
LAM = 1/sqrt(OF);   % the bandwidth factor set so that we have O(N) operations/time step

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;        % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;          % string length
rhoA = par.rhoA;    % string mass per unit length
T = par.T;          % there will be tension
K = par.K;          % contact stiffness constant
alp = par.alp;      % contact power law exponent
ubo = par.ubo;      % barrier level
rs = par.rs;        % relative position along the string for monitoring

%% NON-APPLICABLE PARAMETERS %%%%%
EI = 0;
eta0 = 0;  
eta2 = 0;

%% INITIAL VALUES %%%%
ui = par.ui;        % initial string state

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);    % fundamental frequency
om1 = 2*pi*f1;              % angular
Binh = (EI*pi^2)/(T*L^2);   
m = (rhoA*L)/2;             % modal mass
xi = (dt^2)/m;              % input scalar

%% NUMBER OF MODES %%%%%%%%%%%%
M = floor((LAM/dt)*sqrt(2*m*L/T));

%% BARRIER POINTS %%%%%%%%%%%%%%%
N = M;                      % number of points equals number of modes
dx = L/N;                   % spatial resolution
xb = (-0.5 + (1:N))*dx;     % the barrier points

%% MODAL CONSTANTS %%%%%%%%%%%%
indm = ((1:M)');                    % modal index
bet = (indm*(pi/L));                % wave numbers
k = 0.5*L*(EI*bet.^4 + T.*bet.^2);  % modal stiffness 
r = rhoA*L*(eta0 + eta2*bet.^2);    % modal damping
sigm = (r./(2*m));                  % attenuation
om0 = (sqrt(k/m));                  % angular frequency
UPS = (exp(-sigm*dt));
GAM = (sqrt(sigm.^2 - om0.^2));
OM = (cosh(dt*sqrt(sigm.^2 - om0.^2)));
AA = (2*OM.*UPS);
BB = (1 + UPS.^2);
CC = (0.25*xi*(AA + BB));
CCinv = 1./CC;
khat = ((4*m/dt^2)*(BB - AA)./(BB + AA));
rhat = ((2*m/dt)*(4 - 2*BB)./(BB + AA));

%% VECTORS & MATRICES %%%%%%%
hs = (sin(bet*rs*L));
hsT = hs';
H = sparse(sin(bet*xb));
HT = H';
w = -sparse((EI*bet.^3 + (T*bet)).*((-1).^indm));
wT = w';
I = speye(N);
C = sparse(diag(CC));
Q = HT*C*H;

%% INITIALISATION %%%%%%%%%%%%%%%%%
ut = zeros(M,1);                % u tilde at time (n)
utm = zeros(M,1);               % u tilde at time (n-1)
ut(1) = ui;                     % first mode (t = 0)
utm(1) = ui*cosh(-GAM(1)*dt);   % first mode (t = -dt)
psimh = 0;
qm_gam = 0;
ggm = zeros(N,1);
ggmT = zeros(N,1);

%% OUTPUT VECTORS %%%%%%%%%%%%
output.Fstr = zeros(1,Ns);      % string force (at x = L)
output.us = zeros(1,Ns);        % string displacement (at x = rs*L)
output.vs = zeros(1,Ns);        % string velocity (at x = rs*L)
output.H = zeros(1,Ns);         % total energy (at t = (n+1/2)*dt)
output.Vc = zeros(1,Ns);        % contact energy (at t = (n+1/2)*dt)
output.psi = zeros(1,Ns);       % auxiliary variable (at t = (n+1/2)*dt)
output.term = zeros(1,Ns);

%% PLOT PREPARATION 
if F_plot == 1
    ymax = 1000*0.0025;
    figure(1);
    clf;
    grid;
    axis([0 L -ymax ymax]);
    set(gca,'Box','on');
    set(gca,'Layer','top');
end

indsel = [];

%% LET THE COMMAND WINDOW KNOW WHAT'S HAPPENING
fprintf(1,'\n EXP-3-ME (OF = %d)',OF);

%% TIME-STEPPING LOOP %%%%
EPS = eps;
EPS2 = eps^2;
tic;
for n=1:Ns

    %plot string state
    if F_plot
        figure(1);
        us = hsT*ut;
        hh = area([0 L],3000*[ubo ubo],1000*ubo,'LineStyle','none','FaceColor',0.9*[1 1 1]);
        hold on;
        uu = HT*ut;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(xb,1000*uu,'b.-');
        plot(rs*L,1000*us,'ro');
        hold off;
        axis([0 L -ymax ymax]);
        drawnow;
        pause(0.0001);
    end

    %calculate history varables
    zt = 0.5*(BB.*utm - AA.*ut);
    z = HT*zt;                  % this is a costly line, as HT is dense
    y = HT*ut - ubo;            % this is a costly line, as HT is dense
    Phi = (K/(alp+1))*max(0,y).^(alp+1);  % contact potential density 
    Vc = dx*sum(Phi) + V0;
    
    %calculate gradient vector
    gg = ((K*dx)/sqrt(2*Vc))*max(0,y).^alp;     % nominal gradient
    ggT = gg.';
    q_gam = ggT*Q*gg;           % <- OPTIMISE THIS?
    if q_gam > 0 
        z_gam = ggT*z; 
        gamP = 2*(sqrt(z_gam^2 + q_gam*psimh^2) - z_gam)/(sqrt(EPS*q_gam*z_gam^2 + (q_gam*psimh)^2));    % root of quadratic equation            
        g = min(gamP,1)*gg;
    elseif q_gam <= 0 & qm_gam > 0
        z_thet = ggmT*z;
        thetP = 2*(sqrt(z_thet^2 + qm_gam*psimh^2) - z_thet)/(sqrt(EPS*qm_gam*z_thet^2 + (qm_gam*psimh)^2));    % root of quadratic equation            
        g = thetP*ggm;
    else
        g = zeros(N,1);
    end
    
    %calculate step vector
    gt = H*g;                   % this is a costly line, as H is dense
    gtT = gt.';
    ht = CC.*gt;
    htT = ht.';
    den = (1 + 0.25*gtT*ht);
    temp = -psimh*gt - 2*CCinv.*zt;
    coef = (0.25/den)*htT*temp;
    st = CC.*temp - coef*ht;
    
    %update variables
    %psiph = max(0,psimh + 0.5*gtT*st);    
       psiph = psimh + 0.5*gtT*st;    
%    psiph_true = psimh + 0.5*gtT*st
    utp = st + utm;
    
    %record signals
    vs = hsT*(utp - utm)/(2*dt);   
    output.vs(n) = vs;
    
    if F_record
        us = hsT*ut;
        output.us(n) = us;
        f = -0.5*(psiph + psimh)*g;
        Fstr = wT*ut;
        output.Fstr(n) = Fstr;
        %energy update
        duth = (utp - ut)/dt;
        utph = (utp + ut)/2;
        Vcph = 0.5*psiph^2;      
        Hph = 0.5*m*duth'*duth + 0.5*utph'*diag(khat)*utph + Vcph;
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
        output.psi(n) = psiph;
    end

    %must remember this
    utm = ut;
    ut = utp; 
    psimh = psiph;
    qm_gam = q_gam;
    ggm = gg;
    ggmT = ggT;
end
TIM = toc;

%% REPORT RTF %%%%%%%%%%%%%%%%%
fprintf(1,' RTF = %f',TIM/par.dur);
