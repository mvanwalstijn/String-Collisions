% test a scheme for string-barrier case study
% Maarten van Walstijn 2023
clear;

%% SCHEME CHOICE %%%%%%%
% modal expansion options: 'IMP-1-ME', 'IMP-2-ME', 'EXP-0-ME','EXP-3-ME',' LI-4-ME'
% finite difference options: 'IMP-1-FD', 'IMP-2-FD', 'EXP-0-FD', 'EXP-3-FD',' LI-4-FD'
scheme = 'EXP-3-FD';           
%scheme = 'IMP-2-ME';           
%scheme = ' LI-4-ME';           % note the space at the start

%% SYSTEM PARAMETERS %%%%
par = parStringBarrier;     % reads script to load physical parameters
Fs = 44100;                 % base rate
LAM = 0.9;  % bandwidth factor for FD schemes (does not apply to ME schemes, which use LAM = 1/sqrt(OF))

%% OVERSAMPLING FACTORS TO BE TESTED (e.g. OF = [1 2 4])
OF = [4 16];

%% VARIABLE CHOICE (use var = 2 for representative RTFs)%%%%%%%
var = 2;
% options: 
% 1 = mid-point displacement
% 2 = mid-point velocity <- ONLY THIS OPTION GIVES REPRESENTATIVE RTFs (F_record = 1)
% 3 = string force at x = L
% 4 = contact potential
% 5 = system energy
% 6 = auxiliary variable <- is recorded for explicit schemes only

%% SET FLAGS %%%%%%%%%%%%%%%%%%
F_anim = 0;         % set to 1 to animate string motion
F_record = 1;       % F_record must be one for variables other than vs
if var == 2
    F_record = 0;   % not recording all variables, so we have representative RTFs 
end

%% COMPUTE EXACT SOLUTIONS (ANALYTIC, CABANNES) %%%%%%%%%%%%%%
f1 = sqrt(par.T/par.rhoA)/(2*par.L);
tau1 = 1/f1;
tauq = tau1/4;
tau2 = 1.5*tau1;
dt = 1/Fs;
Ns = ceil(Fs*par.dur)+1;
F0 = par.T*par.ui*pi/par.L;

%mid-point displacement
uMP_ES = zeros(1,Ns);
tt = (0:(Ns-1))*dt;
uMP_FREE = par.ui*cos(2*pi*f1*tt);

%mid-point velocity
vMP_ES = zeros(1,Ns);

%string force
Fstr_ES = zeros(1,Ns);
for n = 1:Ns
    t = (n-1)*dt;
    tr = rem(t,tau2);
    if tr <= (4/3)*tauq
        uMP_ES(n) = par.ui*cos(2*pi*f1*tr);
        vMP_ES(n) = -2*pi*f1*par.ui*sin(2*pi*f1*tr);
        Fstr_ES(n) = F0*cos(2*pi*f1*tr);
    elseif tr < 2*tauq
        uMP_ES(n) = par.ubo*(sin(3*pi*f1*tr) + 1);
        vMP_ES(n) = 3*pi*f1*par.ubo*(cos(3*pi*f1*tr));
        Fstr_ES(n) = F0*cos(2*pi*f1*tr);
    elseif tr < 3*tauq
        uMP_ES(n) = -2*par.ubo*(cos(2*pi*f1*tr) + 1);
        vMP_ES(n) = 2*pi*f1*2*par.ubo*(sin(2*pi*f1*tr));
        Fstr_ES(n) = -F0*cos(2*pi*f1*tr);
    elseif tr < 4*tauq
        uMP_ES(n) = 2*par.ubo*(cos(2*pi*f1*tr) - 1);
        vMP_ES(n) = -2*pi*f1*2*par.ubo*(sin(2*pi*f1*tr));
        Fstr_ES(n) = F0*cos(2*pi*f1*tr);
    elseif tr < (4+2/3)*tauq
        uMP_ES(n) = par.ubo*(cos(3*pi*f1*tr) + 1);
        vMP_ES(n) = -3*pi*f1*par.ubo*(sin(3*pi*f1*tr));
        Fstr_ES(n) = -F0*cos(2*pi*f1*tr);
    elseif tr < 6*tauq
        uMP_ES(n) = 2*par.ubo*(cos(2*pi*f1*tr));
        vMP_ES(n) = -2*pi*f1*2*par.ubo*(sin(2*pi*f1*tr));
        Fstr_ES(n) = -F0*cos(2*pi*f1*tr);
    end
end


%% SIMULATIONS %%%%%%%%%%%%%%
tt = (0:(Ns-1))*dt;
figure(2);
clf;
ax1 = subplot(2,1,1);
box on;
grid;
xlim([0 1000*par.dur]);
hold on;
title([scheme ' (full bandwidth)']);
ax2 = subplot(2,1,2);
box on;
grid;
xlim([0 1000*par.dur]);
xlabel('time (ms)');
title([scheme ' (decimated)']);
hold on;
if var == 1
    axes(ax1); ylabel('displacement (m)');
    axes(ax2); ylabel('displacement (m)');
elseif var == 2
    axes(ax1); ylabel('velocity (m/s)');
    axes(ax2); ylabel('velocity (m/s)');
elseif var == 3
    axes(ax1); ylabel('string force (N)');
    axes(ax2); ylabel('string force (N)');
elseif var == 4
    axes(ax1); ylabel('contact potential (J)');
    axes(ax2); ylabel('contact potential (J)');
elseif var == 5
    axes(ax1); ylabel('energy (J)');
    axes(ax2); ylabel('energy (J)');
elseif var == 6
    axes(ax1); ylabel('\psi');
    axes(ax2); ylabel('\psi');
end

for k=1:length(OF)    
    if scheme == 'IMP-1-ME'
        [outp,t,dt,tau] = SB_scheme_IMP_1_ME(par,OF(k)*Fs,F_record,F_anim);                                  
    elseif scheme == 'IMP-2-ME'
        [outp,t,dt,tau] = SB_scheme_IMP_2_ME(par,OF(k)*Fs,F_record,F_anim);                                  
    elseif scheme == 'EXP-0-ME'
        [outp,t,dt,tau] = SB_scheme_EXP_0_ME(par,OF(k)*Fs,F_record,F_anim);
    elseif scheme == 'EXP-3-ME'
        [outp,t,dt,tau] = SB_scheme_EXP_3_ME(par,OF(k)*Fs,F_record,F_anim);
    elseif scheme == ' LI-4-ME'
        [outp,t,dt,tau] = SB_scheme_LI_4_ME(par,OF(k)*Fs,F_record,F_anim); 
    elseif scheme == 'IMP-1-FD'
        [outp,t,dt,tau] = SB_scheme_IMP_1_FD(par,OF(k)*Fs,LAM,F_record,F_anim);
    elseif scheme == 'IMP-2-FD'
        [outp,t,dt,tau] = SB_scheme_IMP_2_FD(par,OF(k)*Fs,LAM,F_record,F_anim); 
    elseif scheme == 'EXP-0-FD'
        [outp,t,dt,tau] = SB_scheme_EXP_0_FD(par,OF(k)*Fs,LAM,F_record,F_anim); 
    elseif scheme == 'EXP-3-FD'
        [outp,t,dt,tau] = SB_scheme_EXP_3_FD(par,OF(k)*Fs,LAM,F_record,F_anim);
    elseif scheme == ' LI-4-FD'
        [outp,t,dt,tau] = SB_scheme_LI_4_FD(par,OF(k)*Fs,LAM,F_record,F_anim);
    end

    axes(ax1);    
    if var == 1
        hleg1(k) = plot(1000*t,outp.us,'-');
        sigD = decimate(outp.us,OF(k),35,'fir');
    elseif var == 2
        hleg1(k) = plot(1000*t,outp.vs,'-');
        sigD = decimate(outp.vs,OF(k),35,'fir');
    elseif var == 3
        hleg1(k) = plot(1000*t,outp.Fstr,'-');
        sigD = decimate(outp.Fstr,OF(k),35,'fir');
    elseif var == 4
        hleg1(k) = plot(1000*t,outp.Vc,'-');
        sigD = decimate(outp.Vc,OF(k),35,'fir');
    elseif var == 5
        hleg1(k) = plot(1000*t,outp.H,'-');
        sigD = decimate(outp.H,OF(k),35,'fir');
   elseif var == 6
        hleg1(k) = plot(1000*t,outp.psi,'.-');
        sigD = decimate(outp.psi,OF(k),35,'fir');
    end
    drawnow;
    LEG1{k}=strcat('OF = ',num2str(OF(k)));
    tD = (0:length(sigD)-1)*(1/Fs);
    axes(ax2);    
    hleg2(k) = plot(1000*tD,sigD,'-');
    drawnow;
    LEG2{k}=strcat('OF = ',num2str(OF(k)));
end
if var == 1
    axes(ax1);    
    plot(1000*tt,uMP_ES,'k--');
    hold off;
    axes(ax2);    
    plot(1000*tt,uMP_ES,'k--');
    hold off;
elseif var == 2
    axes(ax1);    
    plot(1000*tt,vMP_ES,'k--');
    hold off;
    axes(ax2);    
    plot(1000*tt,vMP_ES,'k--');
    hold off;
elseif var == 3
    axes(ax1);    
    plot(1000*tt,Fstr_ES,'k--');
    hold off;
    axes(ax2);    
    plot(1000*tt,Fstr_ES,'k--');
    hold off;        
end
axes(ax1);
legend(hleg1,LEG1);
xlim([0 1000*par.dur]);
axes(ax2);    
legend(hleg2,LEG2);
xlim([0 1000*par.dur]);

