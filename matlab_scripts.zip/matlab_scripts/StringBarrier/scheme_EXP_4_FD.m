% scheme EXP-4-FD (string-barrier with FD)
function[output,t,dt,TIM] = scheme_EXP_4_FD(par,Fs,LAM,F_record,F_plot)

V0 = eps;           % the energy gauge need not be more than the machine epsilon
OF = Fs/44100;      % the oversampling factor (w.r.t. 44.1 kHz)

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;        % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;                  % string length
rhoA = par.rhoA;            % mass per unit length
T = par.T;                  % there will be tension
K = par.K;                  % contact stiffness per unit length
alp = par.alp;              % contact power law exponent
ubo = par.ubo;              % the barrier offset level
rs = par.rs;                % the relative monitoring position on the string

%% INITIAL VALUES %%%%
ui = par.ui;                % initial state

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);    % the string's fundamental frequency
om1 = 2*pi*f1;              % angular

%% FD GRID CONSTANTS %%%%%%%%%
dxmin = sqrt(T/rhoA)*dt;    % the smallest allowable dx for stability
M = floor(LAM*L/dxmin);     % number of segments
dx = L/M;                   % spatial resolution
N = M - 1;                  % numer of nodes
x = (1:N)*dx;               % position vector

%% FD COEFICIENTS & MATRICES
lam = sqrt(T/rhoA)*dt/dx;                   % Courant number
xi = (dt^2)/(rhoA);                         % input scalar
I = speye(M-1);                             % identity matters
D2 = sparse(toeplitz([-2 1 zeros(1,N-2)])); % second spatial derivative matrix
C = xi/dx;                                  % force scaling constant
hout = make_interpolant_order3(x/L,rs);    % interpolant for output

%% INITIALISATION %%%%%%%%%%%%%%%%%
ub = ui*sin(pi*x/L)';       % ub = displament at time (n)
ubm = ub*cos(-om1*dt);      % ubm = displament at time (n-1)
psimh = 0;


%% OUTPUT VECTORS %%%%%%%%%%%%
output.us = zeros(1,Ns);    % string displacement at x = rs*L
output.vs = zeros(1,Ns);    % string velocity at x = rs*L
output.Fstr = zeros(1,Ns);  % string force on end at x = L
output.Vc = zeros(1,Ns);    % the contact potential at time instants (n+1/2)
output.H = zeros(1,Ns);     % the pseuod-energy at time instants (n+1/2)
output.psi = zeros(1,Ns);       % auxiliary variable (at t = (n+1/2)*dt)

%% PLOT PREPARATION %%%%
if F_plot == 1
    umax = 1000*0.0025;     % plotted in mm, max value
    figure(1);
    clf;
    grid;
    axis([0 L -umax umax]);
    set(gca,'Box','on');
    set(gca,'Layer','top')
end

%% LET THE COMMAND WINDOW KNOW WHAT'S HAPPENING
fprintf(1,'\n EXP-4-FD (OF = %d)',OF);

%% TIME-STEPPING LOOP %%%%
EPS = eps;
EPS2 = eps^2;
tic;
for n=1:Ns
    %plot string state
    if F_plot
        figure(1);
        us = hout*ub;
        hh = area([0 L],3000*[ubo ubo],1000*ubo,'LineStyle','none','FaceColor',0.9*[1 1 1]);
        hold on;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(x,1000*ub,'b.-');
        plot(rs*L,1000*us,'ro');
        hold off;
        axis([0 L -umax umax]);
        pause(0.0001);
    end
    %calculate required variables
    z = ubm - (I + 0.5*(lam^2)*D2)*ub;
    y = ub - ubo;
    Phi = (K/(alp+1))*max(0,y).^(alp+1);  % contact potential density 
    Vc = dx*sum(Phi) + V0;
    
    %calculate gradient vector
    sz = tanh(z/EPS);
    g = sz.*(psimh*dx)./(abs(z)+EPS);      % g for no contact        
    SCAL = ((K*dx)/sqrt(2*Vc));
    for j = 1:N
        if y(j) >= 0        
            g(j) = SCAL*y(j)^alp;   % overwrite for contact points
        end
    end
    if psimh < 0
        g = -g;
    end
    
    %calculate step vector
    gT = g.';
    h = C*g;
    hT = h.';
    den = (1 + 0.25*gT*h);
    temp = -psimh*g - (2/C).*z;
    coef = (0.25/den)*hT*temp;
    s = C*temp - coef*h;
    
    %update variables
    psiph = psimh + 0.5*gT*s;
    ubp = s + ubm;
            
    %record force signal
    vs = hout*(ubp - ubm)/(2*dt);
    output.vs(n) = vs;
    if F_record
        us = hout*ub;
        f = -0.5*(psiph + psimh)*g;
        Vcph = 0.5*psiph^2;      
        Hph = (-(0.5*T/dx^2)*ubp'*D2*ub + 0.5*(rhoA/dt^2)*(ubp - ub)'*(ubp -ub))*dx + Vcph;
        output.us(n) = us;
        output.Fstr(n) = (T/dx)*ub(N);
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
        output.psi(n) = psiph;
    end

    %must remember this
    ubm = ub;
    ub = ubp; 
    psimh = psiph;    
end
TIM = toc;

%% REPORT RTF %%%%%%%%%%%%%%%%%
fprintf(1,' RTF = %f',TIM/par.dur);

