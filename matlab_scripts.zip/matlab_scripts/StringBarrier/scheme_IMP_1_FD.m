% scheme IMP-1-FD (string-barrier with FD)
function[output,t,dt,TIM] = scheme_IMP_1_FD(par,Fs,LAM,F_record,F_plot)

OF = Fs/44100;      % the oversampling factor (w.r.t. 44.1 kHz)

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;        % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;                  % string length
rhoA = par.rhoA;            % mass per unit length
T = par.T;                  % there will be tension
K = par.K;                  % contact stiffness per unit length
alp = par.alp;              % contact power law exponent
ubo = par.ubo;              % the barrier offset level
rs = par.rs;                % the relative monitoring position on the string

%% INITIAL VALUES %%%%
ui = par.ui;                % initial state

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);    % the string's fundamental frequency
om1 = 2*pi*f1;              % angular

%% FD GRID CONSTANTS %%%%%%%%%
dxmin = sqrt(T/rhoA)*dt;    % the smallest allowable dx for stability
M = floor(LAM*L/dxmin);     % number of segments
dx = L/M;                   % spatial resolution
N = M - 1;                  % numer of nodes
x = (1:N)*dx;               % position vector

%% FD COEFICIENTS & MATRICES
lam = sqrt(T/rhoA)*dt/dx;                   % Courant number
xi = (dt^2)/(rhoA);                         % input scalar
I = speye(M-1);                             % identity matters
D2 = sparse(toeplitz([-2 1 zeros(1,N-2)])); % second spatial derivative matrix
C = xi/dx;                                  % force scaling constant
hout = make_interpolant_order3(x/L,rs);    % interpolant for output

%% INITIALISATION %%%%%%%%%%%%%%%%%
ub = ui*sin(pi*x/L)';       % ub = displament at time (n)
ubm = ub*cos(-om1*dt);      % ubm = displament at time (n-1)
Phi = (zeros(N,1));         % contact potential density vector at time (n)
ym = zeros(N,1);            % compression variabe vector at time (n-1)

%% OUTPUT VECTORS %%%%%%%%%%%%
output.us = zeros(1,Ns);    % string displacement at x = rs*L
output.vs = zeros(1,Ns);    % string velocity at x = rs*L
output.Fstr = zeros(1,Ns);  % string force on end at x = L
output.Vc = zeros(1,Ns);    % the contact potential at time instants (n+1/2)
output.H = zeros(1,Ns);     % the pseudo-energy at time instants (n+1/2)
output.psi = zeros(1,Ns);   % placeholder, not applicable in this scheme

%% PLOT PREPARATION %%%%
if F_plot == 1
    umax = 1000*0.0025;     % plotted in mm, max value
    figure(1);
    clf;
    grid;
    axis([0 L -umax umax]);
    set(gca,'Box','on');
    set(gca,'Layer','top')
end

%% LET THE COMMAND WINDOW KNOW WHAT'S HAPPENING
fprintf(1,'\n IMP-1-FD (OF = %d)',OF);

%% TIME-STEPPING LOOP %%%%
maxiter = 100;
tol = eps^2;
s = 300*eps*ones(M-1,1);
EPS = eps;
EPS2 = eps^2;
tic;
for n=1:Ns
    %plot string state
    if F_plot
        figure(1);
        us = hout*ub;
        hh = area([0 L],3000*[ubo ubo],1000*ubo,'LineStyle','none','FaceColor',0.9*[1 1 1]);
        hold on;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(x,1000*ub,'b.-');
        plot(rs*L,1000*us,'ro');
        hold off;
        axis([0 L -umax umax]);
        pause(0.0001);
    end
    %calculate required variables
    z = ubm - (I + 0.5*(lam^2)*D2)*ub;
    y = ub - ubo;
    Phim = (K/(alp+1))*max(0,ym).^(alp+1);
    dPhim = K*max(0,ym).^alp;
    ddPhim = K*alp*max(0,ym).^(alp-1);    

    %Newton iterative solver
    sdiff = 1;
    iter = 0;
    while sdiff > tol & iter < maxiter
        Phip = (K/(alp+1))*max(0,s+ym).^(alp+1);
        dPhip = K*max(0,s+ym).^alp;        
        f = -dx*(((Phip - Phim).*s)./(s.^2 + EPS2) + dPhim.*(EPS2./(s.^2 + EPS2)));
        df = -dx*((dPhip.*s - Phip + Phim)./(s.^2 + EPS2) + (EPS2./(s.^2 + EPS2)).*(0.5*ddPhim));
        F = s - C*f + 2*z;          % the function that needs to be zero
        J = 1 - C*df;               % the Jacobian is diagonal
        snew = s - F./J;             % so we can do elementwise division        
        sdiff = (snew - s)'*(snew - s); % spot the difference
        s = snew;
        iter = iter + 1;
    end
    if iter >= maxiter
        disp('IMP-1-FD: maxiter reached!'); 
    end
    
    %update displacement & string energy
    ubp = s + ubm;    
        
    %record force signal
    vs = hout*(ubp - ubm)/(2*dt);
    output.vs(n) = vs;
    if F_record
        us = hout*ub;
        Phip = (K/(alp+1))*max(0,ym+s).^(alp+1);
        Vcph = sum(0.5*(Phip+Phi))*dx;
        Hph = (-(0.5*T/dx^2)*ubp'*D2*ub + 0.5*(rhoA/dt^2)*(ubp - ub)'*(ubp -ub))*dx + Vcph;
        output.us(n) = us;
        output.Fstr(n) = (T/dx)*ub(N);
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
    end

    %must remember this
    ubm = ub;
    ub = ubp; 
    Phi = Phip;    
    ym = y;
end
TIM = toc;

%% REPORT RTF %%%%%%%%%%%%%%%%%
fprintf(1,' RTF = %f',TIM/par.dur);

