% file for testing string_barrier collision schemes
clear;

%% SCHEME CHOICE %%%%%%%
% implicit options: 'IMP-1', 'IMP-2', 
% explicit options: 'EXP-0', 'EXP-1', 'EXP-2', 'EXP-3', 'EXP-4'
scheme = 'EXP-4';           

%% SYSTEM PARAMETERS %%%%
par = parC4;     % reads script to load physical parameters
Fs = 44100;      % base rate
LAM = 1;         % for hammer-string, no issues with setting this to unity.       

%% OVERSAMPLING FACTORS TO BE TESTED (e.g. OF = [1 2 4])
OF = [1 4];

%% VARIABLE CHOICE (use var = 2 for representative RTFs)%%%%%%%
var = 3;
% options: 
% 1 = hammer displacement
% 2 = string displacement at contact point 
% 3 = contact force
% 4 = contact potential
% 5 = system energy
% 6 = auxiliary variable <- is recorded for explicit schemes only
% 7 = gradient variable <- is recorded for explicit schemes only
% 8 = string force

%% SET FLAGS %%%%%%%%%%%%%%%%%%%%
F_anim = 0;         % set to 1 to animate motion 
if var == 3
    F_record = 0;
else
    F_record = 1;
end

%% SIMULATIONS %%%%%%%%%%%%%%
figure(2);
clf;
ax1 = subplot(2,1,1);
box on;
grid;
xlim([0 1000*par.dur]);
hold on;
title([scheme ' (full bandwidth)']);
ax2 = subplot(2,1,2);
box on;
grid;
xlim([0 1000*par.dur]);
xlabel('time (ms)');
title([scheme ' (decimated)']);
hold on;
if var == 1
    axes(ax1); ylabel('displacement (m)');
    axes(ax2); ylabel('displacement (m)');
elseif var == 2
    axes(ax1); ylabel('velocity (m/s)');
    axes(ax2); ylabel('velocity (m/s)');
elseif var == 3
    axes(ax1); ylabel('contact force (N)');
    axes(ax2); ylabel('contact force (N)');
elseif var == 4
    axes(ax1); ylabel('contact potential (J)');
    axes(ax2); ylabel('contact potential (J)');
elseif var == 5
    axes(ax1); ylabel('energy (J)');
    axes(ax2); ylabel('energy (J)');
elseif var == 6
    axes(ax1); ylabel('\psi');
    axes(ax2); ylabel('\psi');
elseif var == 7
    axes(ax1); ylabel('g');
    axes(ax2); ylabel('g');
elseif var == 8
    axes(ax1); ylabel('F_{str} (N)');
    axes(ax2); ylabel('F_{str} (N)');
end

for k=1:length(OF)
    if scheme == 'IMP-1'
        [outp,t,dt] = scheme_IMP_1(par,OF(k)*Fs,LAM,F_record,F_anim);                                  
    elseif scheme == 'IMP-2'
        [outp,t,dt] = scheme_IMP_2(par,OF(k)*Fs,LAM,F_record,F_anim);              
    elseif scheme == 'EXP-0'
        [outp,t,dt] = scheme_EXP_0(par,OF(k)*Fs,LAM,F_record,F_anim);
    elseif scheme == 'EXP-1'
        [outp,t,dt] = scheme_EXP_1(par,OF(k)*Fs,LAM,F_record,F_anim);
    elseif scheme == 'EXP-2'
        [outp,t,dt] = scheme_EXP_2(par,OF(k)*Fs,LAM,F_record,F_anim);
    elseif scheme == 'EXP-3'
        [outp,t,dt] = scheme_EXP_3(par,OF(k)*Fs,LAM,F_record,F_anim);
    elseif scheme == 'EXP-4'
        [outp,t,dt] = scheme_EXP_4(par,OF(k)*Fs,LAM,F_record,F_anim);     
    end

    axes(ax1);    
    if var == 1        
        hleg1(k) = plot(1000*t,outp.uh,'.-');
        sigD = decimate(outp.uh,OF(k),15,'fir');
    elseif var == 2
        hleg1(k) = plot(1000*t,outp.us,'.-');
        sigD = decimate(outp.us,OF(k),15,'fir');
    elseif var == 3
        hleg1(k) = plot(1000*t,outp.Fc,'.-');
        sigD = decimate(outp.Fc,OF(k),15,'fir');
    elseif var == 4
        hleg1(k) = plot(1000*t,outp.Vc,'.-');
        sigD = decimate(outp.Vc,OF(k),15,'fir');
    elseif var == 5
        hleg1(k) = plot(1000*t,outp.H,'.-');
        sigD = decimate(outp.H,OF(k),15,'fir');
    elseif var == 6
        hleg1(k) = plot(1000*t,outp.psi,'.-');
        sigD = decimate(outp.psi,OF(k),15,'fir');
    elseif var == 7
        hleg1(k) = plot(1000*t,outp.g,'.-');
        sigD = decimate(outp.g,OF(k),15,'fir');
    elseif var == 8
        hleg1(k) = plot(1000*t,outp.Fstr,'.-');
        sigD = decimate(outp.Fstr,OF(k),15,'fir');
    end
    drawnow;
    LEG1{k}=strcat('OF = ',num2str(OF(k)));
    tD = (0:length(sigD)-1)*(1/Fs);
    axes(ax2);   
    hleg2(k) = plot(1000*tD,sigD,'.-');
    drawnow;
    LEG2{k}=strcat('OF = ',num2str(OF(k)));
end
axes(ax1);
if var == 1
    plot([0 1000*par.dur],par.ub*[1 1],'k--');
end
legend(hleg1,LEG1);
xlim([0 1000*par.dur]);
axes(ax2);    
if var == 1
    plot([0 1000*par.dur],par.ub*[1 1],'k--');
end
legend(hleg2,LEG2);
xlim([0 1000*par.dur]);





