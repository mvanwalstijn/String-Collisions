% hammer-string model - main plot
clear;
getcols;
LW = 1.5;
par = parC4;
FS = 9;

%% SIMULATIONS %%%%%%%%%%%%%%
Fs = 1*44100;
LAM = 0.9;
OSES = 32;
par.vhi = -4;
[outputES,tES,dtES] = scheme_IMP_1(par,OSES*Fs,LAM,0,0);
[outputIMP1,t,dt] = scheme_IMP_1(par,Fs,LAM,0,0);
[outputIMP2,t,dt] = scheme_IMP_2(par,Fs,LAM,0,0);
[outputEXP1,t,dt] = scheme_EXP_1(par,Fs,LAM,0,0);
[outputEXP2,t,dt] = scheme_EXP_2(par,Fs,LAM,0,0);
[outputEXP3,t,dt] = scheme_EXP_3(par,Fs,LAM,0,0);
[outputEXP4,t,dt] = scheme_EXP_4(par,Fs,LAM,1,0);

%% PLOTTING %%%%%%%%%%%%%%%%%%%
HF = figure(2);
clf;

subplot(2,3,1);
hold on;
plot(1000*t,-outputIMP1.Fc,'Color',COLS(1,:),'LineWidth',LW);
plot(1000*tES,-outputES.Fc,'k--','LineWidth',LW);
hold off;
box on;
grid;
axis([0 1000*par.dur 0 30]);
ylabel('force (N)');
legend('IMP-1','ES');
%text(0.1,26,'(a)');
set(gca,'FontSize',FS);

subplot(2,3,4);
hold on;
plot(1000*t,-outputIMP2.Fc,'Color',COLS(2,:),'LineWidth',LW);
plot(1000*tES,-outputES.Fc,'k--','LineWidth',LW);
hold off;
box on;
grid;
axis([0 1000*par.dur 0 30]);
xlabel('time (ms)');
ylabel('force (N)');
legend('IMP-2','ES');
%text(0.1,26,'(d)');
set(gca,'FontSize',FS);


subplot(2,3,2);
hold on;
plot(1000*t,-outputEXP1.Fc,'Color',COLS(3,:),'LineWidth',LW);
plot(1000*tES,-outputES.Fc,'k--','LineWidth',LW);
hold off;
box on;
grid;
axis([0 1000*par.dur 0 30]);
%xlabel('time (ms)');
%ylabel('force (N)');
legend('EXP-1','ES');
%text(0.1,26,'(b)');
set(gca,'FontSize',FS);

subplot(2,3,5);
hold on;
plot(1000*t,-outputEXP2.Fc,'Color',COLS(4,:),'LineWidth',LW);
plot(1000*tES,-outputES.Fc,'k--','LineWidth',LW);
hold off;
box on;
grid;
axis([0 1000*par.dur 0 30]);
xlabel('time (ms)');
%ylabel('contact force (N)');
legend('EXP-2','ES');
%text(0.1,26,'(e)');
set(gca,'FontSize',FS);

subplot(2,3,3);
hold on;
plot(1000*t,-outputEXP3.Fc,'Color',COLS(5,:),'LineWidth',LW);
plot(1000*tES,-outputES.Fc,'k--','LineWidth',LW);
hold off;
box on;
grid;
axis([0 1000*par.dur 0 30]);
%xlabel('time (ms)');
%ylabel('force (N)');
legend('EXP-3','ES');
%text(0.1,26,'(c)');
set(gca,'FontSize',FS);

subplot(2,3,6);
hold on;
plot(1000*t,-outputEXP4.Fc,'Color',COLS(6,:),'LineWidth',LW);
plot(1000*tES,-outputES.Fc,'k--','LineWidth',LW);
hold off;
box on;
grid;
axis([0 1000*par.dur 0 30]);
xlabel('time (ms)');
%ylabel('contact force (N)');
legend('EXP-4','ES');
%text(0.1,26,'(f)');
set(gca,'FontSize',FS);

HF.Position = [100 100 800 350];  
%exportgraphics(HF,'HammerString.pdf','ContentType','vector');





