function[output,t,dt] = scheme_EXP_4(par,Fs,LAM,F_record,F_plot)
% scheme EXP-4 (hammer-string)
% Maarten van Walstijn 2023

%% TIME CONSTANTS %%%%%%
dur = par.dur;
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;         % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;
rhoA = par.rhoA;
T = par.T;
EI = par.EI;
eta0 = par.eta0;
eta2 = par.eta2;
mh = par.mh;
re = par.re;
kap = par.kap;
alp = par.alp;

%% INITIAL VALUES %%%%
uhi = par.uhi;
vhi = par.vhi;

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);
om1 = 2*pi*f1;
Binh = (EI*pi^2)/(T*L^2);
m = (rhoA*L)/2;
xi = (dt^2)/m;
xih = (dt^2)/mh;
xh = re*L;

%% MODAL CONSTANTS %%%%%%%%%%%%
Aeq = Binh*om1^2 - (1/16)*pi^4*eta2^2;
Beq = om1^2 - 2*(pi/L)^2*eta0*eta2;
Ceq = eta0^2 + (pi/dt)^2;
M = floor(LAM*sqrt((sqrt(Beq^2+4*Aeq*Ceq) - Beq)/(2*Aeq)));
indm = (1:M)';
bet = (indm*(pi/L));
k = 0.5*L*(EI*bet.^4 + T.*bet.^2);
r = rhoA*L*(eta0 + eta2*bet.^2);
sigm = r./(2*m);
om0 = sqrt(k/m);           % angular frequency
%gam = sqrt(sigm.^2 - om0.^2);
UPS = exp(-sigm*dt);
OM = cosh(dt*sqrt(sigm.^2 - om0.^2));
AA = 2*OM.*UPS;
BB = 1 + UPS.^2;
CC = 0.25*xi*(AA + BB);
khat = (4*m/dt^2)*(BB - AA)./(BB + AA);
rhat = (2*m/dt)*(4 - 2*BB)./(BB + AA);
h = sin(bet*xh);
hT = h';
w = -(EI*bet.^3 + (T*bet)).*((-1).^indm);
wT = w';
q = xih + hT*diag(CC)*h;

%% INITIALISATION %%%%%%%%%%%%%%%%%
utm = zeros(M,1);       % u tilde at time (n-1)
ut = zeros(M,1);        % u tilde at time (n)
uh = uhi;               % uh at time (n)            
uhm = uhi - dt*vhi;     % uh at time (n-1)
usm = 0;                % u at x = xh at time (n-1)
psimh = 0;

%% OUTPUT VECTORS %%%%%%%%%%%%
output.Fc = zeros(1,Ns);
if F_record
    output.Fstr = zeros(1,Ns);
    output.uh = zeros(1,Ns);
    output.us = zeros(1,Ns);
    output.H = zeros(1,Ns);
    output.Vc = zeros(1,Ns);
    output.psi = zeros(1,Ns);
    output.g = zeros(1,Ns);
end


%% TIME-STEPPING LOOP %%%%
if F_plot == 1
    NN = 50;
    xx = (0:NN)*(L/NN);
    VV = (sin(bet*xx))';
    ymax = 0.004;
    figure(1);
    clf;
    grid;
    axis([0 L -ymax ymax]);
end

maxiter = 100;
iter = 0;
tol = eps;
s = 3*eps;
EPSIL = eps;
for n=1:Ns
    %plot string state
    if F_plot
        figure(1);
        uu = VV*ut;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(xx,uu,'b.-');
        plot(re*L,uh,'ro');
        hold off;
        axis([0 L -ymax ymax]);
        pause(0.0001);
    end
    
    %calculate history varables
    zt = 0.5*(BB.*utm - AA.*ut);
    zh = uhm - uh;
    z =  hT*zt - zh;
    us = hT*ut;    
    y = us - uh;
    ym = usm - uhm;
    
    sz = tanh(z/EPSIL);
    g = sz*psimh/(abs(z)+EPSIL);      % g for no contact    
    if y >= 0 & kap > 0 
        g = sqrt(0.5*kap*(alp+1)*y^(alp-1));    % theory value of g   
        if psimh < 0
            g = -g;
        end
    end
   
    %update equations
    s = -(2*z + q*g*psimh)/(1 + 0.25*q*g^2);
    psiph = psimh + 0.5*g*s;
    Fc = -0.5*(psiph+psimh)*g;  
    utp = utm + CC.*h*Fc - 2*zt;
    uhp = uhm - xih*Fc - 2*zh;
    Fstr = wT*ut;
    
    %record signals
    output.Fc(n) = Fc;
    if F_record
        %energy update
        Vcph = 0.5*psiph^2;
        duhh = (uhp - uh)/dt;
        duth = (utp - ut)/dt;
        utph = (utp + ut)/2;
        Hph = 0.5*m*duth'*duth + 0.5*utph'*diag(khat)*utph + 0.5*mh*duhh^2 + Vcph;
        output.Fstr(n) = Fstr;
        output.uh(n) = uh;
        output.us(n) = us;
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
        output.psi(n) = psiph;
        output.g(n) = g;
    end


    %memorise
    utm = ut;
    ut = utp; 
    uhm = uh;
    uh = uhp;
    usm = us;
    psimh = psiph;
    
end





