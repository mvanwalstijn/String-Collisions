function[par] = parMvW1

%% TIME CONSTANTS %%%%%%
par.dur = 0.0004;              % duration

%% PHYSICAL PARAMETERS %%%%%%%%%%
par.m = 0.01;              % mass
par.f0 = 0;              % oscillator frequency (k = (2*pi*f0)*m)
par.sigm = 0;               % attenuation constant (r = 2*m*sigm)
par.alp = 1.3;             % collision exponent
par.kap = 1e9;              % collision stiffness
par.ub = 0.0001;             % barrier position

%% INITIAL VALUES (at t = 0 ) %%%%
par.ui = 0;                % initial displacement 
par.vi = 2;                % initial velocity 

