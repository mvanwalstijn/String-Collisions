function[output,t,dt] = scheme_IMP_1(par,Fs)
% Non-Linearly Implicit Scheme for Mass-Barrier Collision (scheme IMP-1)
% Maarten van Walstijn 2023

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;         % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
m = par.m;              % mass
f0 = par.f0;            % oscillator frequency
sigm = par.sigm;        % attenuation constant
alp = par.alp;          % collision exponent
kap = par.kap;          % collision stiffness
ub = par.ub;            % barrier position

%% INITIAL VALUES %%%%%%%%%%%%%%%%%
ui = par.ui;                % initial displacement 
vi = par.vi;                % initial velocity 

%% CONVENIENT CONSTANTS %%%%%%
om0 = 2*pi*f0;           % angular frequency
gam = sqrt(sigm^2 - om0^2);
UPS = exp(-sigm*dt);
OM = cosh(gam*dt);
xi = (dt^2)/m;
AA = 2*OM*UPS;
BB = 1 + UPS^2;
CC = 0.25*xi*(AA + BB);
q = CC;
khat = (4*m/dt^2)*(BB - AA)/(BB + AA);
rhat = (2*m/dt)*(4 - 2*BB)/(BB + AA);

%% INITIALISATION %%%%%%%%%%%%
u = ui;            % u at time (n) 
if abs(gam) < 1e-15
    um = (1/UPS)*(ui - (vi+sigm*ui)*dt); 
else
    um = (1/UPS)*(ui*cosh(gam*dt) - (vi+sigm*ui)*(sinh(gam*dt))/gam);
end
Vc = 0;

%% OUTPUT VECTORS %%%%%%%%%%%%
output.u = zeros(1,Ns);
output.H = zeros(1,Ns);
output.Vc = zeros(1,Ns);
output.Fc = zeros(1,Ns);
output.g = zeros(1,Ns);
output.psi = zeros(1,Ns);
output.v = zeros(1,Ns);

%% SAMPLE LOOP %%%%%
maxiter = 100;
tol = eps;
EPS = eps;
EPS2 = eps^2;

for n=1:Ns    
    z = 0.5*(BB*um - AA*u);             % 'history' value
    ym = um - ub;                       % previous contact variable
    Vcm = (kap/(alp+1))*max(0,ym)^(alp+1);
    dVcm = kap*max(0,ym)^alp;
    ddVcm = kap*alp*max(0,ym)^(alp-1);
    
    %NR solver
    s = 100*eps;
    diff = 1;
    i = 0;    
    while diff > tol && i < maxiter
        Vcp = (kap/(alp+1))*max(0,s+ym)^(alp+1);
        dVcp = kap*max(0,s+ym)^alp;
           
        F = s + 2*z + q*(((Vcp - Vcm)*s)/(s^2 + EPS2) + dVcm*(EPS2/(s^2 + EPS2)));
        dF = 1 + q*((dVcp*s - Vcp + Vcm)/(s^2 + EPS2) + (EPS2/(s^2 + EPS2))*(0.5*ddVcm));
        
        snew = s - F/dF;
        diff = abs(snew-s);
        s = snew;
        i = i + 1;
    end
    
    %update equations
    up = s + um;
     
    % compute force & energies
    Vcp = (kap/(alp+1))*max(0,up-ub)^(alp+1);  
    Fc = -((Vcp - Vcm)*s)/(s^2 + EPS2) + dVcm*(EPS2/(s^2 + EPS2));    
    Vcph = 0.5*(Vcp + Vc);
    Hph = 0.5*m*((up-u)/dt)^2 + 0.5*khat*((up+u)/2)^2 + Vcph;
        
    % monitor signals
    output.Fc(n) = Fc;
    output.u(n) = u;
    output.H(n) = Hph;
    output.Vc(n) = Vcph;
    output.v(n) = (up - um)/(2*dt);
        
    % memorise
    um = u;
    u = up;
    Vc = Vcp;
end

