function[H,Hi] = make_interpolant_order3(x1,x2)

N1 = length(x1);
N2 = length(x2);
dx1 = 1/(N1+1);
dx2 = 1/(N2+1);

H = zeros(N2,N1);
for i=1:N2
    x = x2(i);
    mf = x/dx1;
    m = floor(mf);
    D = mf - m;
   
    if m == 0 
        H(i,m+1) = (-D*(D+1)*(D-2)/2) + (D*(D-1)*(D-2)/6); % ghost node
        H(i,m+2) = D*(D+1)*(D-1)/6;
    elseif m == 1
        H(i,m) = (D-1)*(D+1)*(D-2)/2;
        H(i,m+1) = -D*(D+1)*(D-2)/2;
        H(i,m+2) = D*(D+1)*(D-1)/6;
    elseif m == N1-1
        H(i,m-1) = -D*(D-1)*(D-2)/6;
        H(i,m) = (D-1)*(D+1)*(D-2)/2;
        H(i,m+1) = -D*(D+1)*(D-2)/2;
    elseif m == N1
        H(i,m-1) = -D*(D-1)*(D-2)/6;
        H(i,m) = (D-1)*(D+1)*(D-2)/2 - (D*(D+1)*(D-1)/6);   % ghost node
    else
        H(i,m-1) = -D*(D-1)*(D-2)/6;
        H(i,m) = (D-1)*(D+1)*(D-2)/2;
        H(i,m+1) = -D*(D+1)*(D-2)/2;
        H(i,m+2) = D*(D+1)*(D-1)/6;
    end

end
Hi = (dx2/dx1)*H.';

H = sparse(H);
Hi = sparse(Hi);
end

