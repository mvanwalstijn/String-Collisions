% scheme IMP-2-ME (sitar-like)
function[output,t,dt,TIM] = scheme_IMP_2_ME(par,Fs,p,LAM,F_record,F_plot)

OF = Fs/44100;      % the oversampling factor (w.r.t. 44.1 kHz)
%LAM = 1/sqrt(OF);   % the bandwidth factor set so that we have O(N) operations/time step


%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;        % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;          % string length
rhoA = par.rhoA;    % string mass per unit length
T = par.T;          % there will be tension
K = par.K;          % contact stiffness constant
alp = par.alp;      % contact power law exponent
rs = par.rs;        % relative position along the string for monitoring
EI = par.EI;        % stiffness parameter
eta0 = par.eta0;    % damping parameter (freq indep)
eta2 = par.eta2;    % damping parameter (freq dep)
hb = par.hb;        % bridge height
Lb = par.Lb;        % bridge length

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);    % fundamental frequency
om1 = 2*pi*f1;              % angular
Binh = (EI*pi^2)/(T*L^2);   % inharmonicity
m = (rhoA*L)/2;             % modal mass
xi = (dt^2)/m;              % input scalar

%% NUMBER OF MODES %%%%%%%%%%%%
Aeq = Binh*om1^2 - (1/16)*pi^4*eta2^2;
Beq = om1^2 - 2*(pi/L)^2*eta0*eta2;
Ceq = -(eta0^2 + (pi/dt)^2);
ip = sqrt(2*Ceq/(-Beq - sqrt(Beq^2 - 4*Aeq*Ceq)));    %citardauq formula
M = floor(LAM*ip);

%% BARRIER POINTS %%%%%%%%%%%%%%%
N = round(p*M);         % number of bridge points
dx = Lb/N;               % spatial resolution
x_bridge = (-0.5 + (1:N)')*dx; % barrier points
u_bridge = (4*hb/Lb^2)*x_bridge.*(x_bridge - Lb);

%% MODAL CONSTANTS %%%%%%%%%%%%
indm = ((1:M)');              % modal index
bet = (indm*(pi/L));        % wave numbers
k = 0.5*L*(EI*bet.^4 + T.*bet.^2);
r = rhoA*L*(eta0 + eta2*bet.^2);
sigm = (r./(2*m));
om0 = (sqrt(k/m));           % angular frequency
UPS = (exp(-sigm*dt));
gam = (sqrt(sigm.^2 - om0.^2));
OM = (cosh(dt*sqrt(sigm.^2 - om0.^2)));
AA = (2*OM.*UPS);
BB = (1 + UPS.^2);
CC = (0.25*xi*(AA + BB));
khat = ((4*m/dt^2)*(BB - AA)./(BB + AA));
rhat = ((2*m/dt)*(4 - 2*BB)./(BB + AA));

%% VECTORS & MATRICES %%%%%%%
hs = sparse(sin(bet*rs*L));
hsT = hs';
H = sparse(sin(bet*x_bridge'));
HT = H';
w = -sparse((EI*bet.^3 + (T*bet)).*((-1).^indm));
wT = w';
CH = sparse(diag(CC)*H);
Q = sparse(HT*CH);
I = speye(N);

%% INITIALISATION %%%%%%%%%%%%%%%%%
ut = (zeros(M,1));                % u tilde at time (n)
utm = (zeros(M,1));               % u tilde at time (n-1)
ui = -(4*hb*L)/(pi*Lb);           % initial displacement
ut(1) = ui;                       % first mode (t = 0)
C1 = ui;
C2 = ui*sigm(1);
utm(1) = exp(sigm(1)*dt)*(C1*cosh(-gam(1)*dt) + C2*sinh(-gam(1)*dt)/gam(1));
Phimh = (zeros(N,1));       % contact potential density at time (n=1/2)
ym = zeros(N,1);

%% OUTPUT VECTORS %%%%%%%%%%%%
output.Fstr = zeros(1,Ns);      % string force (at x = L)
output.us = zeros(1,Ns);        % string displacement (at x = rs*L)
output.vs = zeros(1,Ns);        % string velocity (at x = rs*L)
output.H = zeros(1,Ns);         % total energy (at t = (n+1/2)*dt)
output.Vc = zeros(1,Ns);        % contact pseudo-energy (at t = (n+1/2)*dt)
output.psi = zeros(1,Ns);       % placeholder, not applicable in this scheme

%% PLOT PREPARATION %%%%
if F_plot == 1
    Na = 100;
    xa = (1:Na)*(L/Na);     % string animation points
    Ha = sparse(sin(bet*xa));
    HaT = Ha.';
    umax = 1000*0.0025;
    figure(1);
    clf;
    grid;
    axis([0 L -umax umax]);
    set(gca,'Box','on');
    set(gca,'Layer','top')
end

%% LET THE COMMAND WINDOW KNOW WHAT'S HAPPENING
fprintf(1,'\n IMP-2-ME (OF = %d)',OF);

%% TIME-STEPPING LOOP %%%%
maxiter = 100;
tol = eps^2;
s = 300*eps*ones(N,1);
EPS = eps;
EPS2 = eps^2;
tic;
for n=1:Ns
    %plot string state
    if F_plot
        figure(1);
        us = hsT*ut;    
        hh = area([0; x_bridge; Lb],1000*[0; u_bridge; 0],'LineStyle','none','FaceColor',[0.85 0.3 0.2]);
        hold on;
        ua = HaT*ut;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(xa,1000*ua,'b.-');
        plot(rs*L,1000*us,'ro');
        hold off;
        axis([0 L -umax umax]);
        drawnow;
        pause(0.0001);
        %pause;
    end


    %calculate history varables
    zt = 0.5*(BB.*utm - AA.*ut);
    z = HT*zt;
    y = HT*ut - u_bridge;
    ystar = 0.5*(y + ym);  
    Phimh = (K/(alp+1))*max(0,ystar).^(alp+1);  % contact potential density
    dPhimh = K*max(0,ystar).^alp;
    ddPhimh = K*alp*max(0,ystar).^(alp-1);
    
    %solve nonlinear vector equation
    sdiff = 1;
    iter = 0;
    while sdiff > tol & iter < maxiter        
        Phiph = (K/(alp+1))*max(0,0.5*s+ystar).^(alp+1);
        dPhiph = K*max(0,0.5*s+ystar).^alp;        
        f = -2*dx*(((Phiph - Phimh).*s)./(s.^2 + EPS2) + 0.5*dPhimh.*(EPS2./(s.^2 + EPS2)));
        df = -2*dx*((0.5*dPhiph.*s - Phiph + Phimh)./(s.^2 + EPS2) + (EPS2./(s.^2 + EPS2)).*(0.125*ddPhimh));
        P = spdiags(-df,0,N,N);        
        F = s - Q*f + 2*z;
        J = I + Q*P;
        snew = s - J\F;
        sdiff = (snew - s)'*(snew - s);
        s = snew;
        iter = iter + 1;
    end
    if iter >= maxiter
        disp('IMP-2-ME: maxiter reached!');
    end
    
    %update variables
    Phiph = (K/(alp+1))*max(0,0.5*s+ystar).^(alp+1);
    f = -2*dx*(((Phiph - Phimh).*s)./(s.^2 + EPS2) + 0.5*dPhimh.*(EPS2./(s.^2 + EPS2)));
    utp = utm + CH*f - 2*zt;
         
    
    %record signals    
    output.Fstr(n) = wT*ut;
    if F_record == 1
        us = hsT*ut;
        output.us(n) = us;
        vs = hsT*(utp - utm)/(2*dt);
        output.vs(n) = vs;        
        duth = (utp - ut)/dt;
        utph = (utp + ut)/2;
        Vcph = dx*sum(Phiph);
        Hph = 0.5*m*duth'*duth + 0.5*utph'*diag(khat)*utph + Vcph;
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
    end

    %must remember this
    utm = ut;
    ut = utp; 
    ym = y;
end
TIM = toc;

%% REPORT RTF %%%%%%%%%%%%%%%%%
fprintf(1,' RTF = %f',TIM/par.dur);

