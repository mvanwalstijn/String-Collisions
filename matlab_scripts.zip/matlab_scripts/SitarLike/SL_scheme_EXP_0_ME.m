% scheme EXP-0-ME (sitar-like)
% Maarten van Walstijn 2023
function[output,t,dt,TIM] = scheme_EXP_0_ME(par,Fs,p,LAM,F_record,F_plot)

V0 = eps;           % the energy gauge need not be more than the machine epsilon
OF = Fs/44100;      % the oversampling factor (w.r.t. 44.1 kHz)

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;        % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;          % string length
rhoA = par.rhoA;    % string mass per unit length
T = par.T;          % there will be tension
K = par.K;          % contact stiffness constant
alp = par.alp;      % contact power law exponent
rs = par.rs;        % relative position along the string for monitoring
EI = par.EI;        % stiffness parameter
eta0 = par.eta0;    % damping parameter (freq indep)
eta2 = par.eta2;    % damping parameter (freq dep)
hb = par.hb;        % bridge height
Lb = par.Lb;        % bridge length

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);    % fundamental frequency
om1 = 2*pi*f1;              % angular
Binh = (EI*pi^2)/(T*L^2);   % inharmonicity
m = (rhoA*L)/2;             % modal mass
xi = (dt^2)/m;              % input scalar

%% NUMBER OF MODES %%%%%%%%%%%%
Aeq = Binh*om1^2 - (1/16)*pi^4*eta2^2;
Beq = om1^2 - 2*(pi/L)^2*eta0*eta2;
Ceq = -(eta0^2 + (pi/dt)^2);
ip = sqrt(2*Ceq/(-Beq - sqrt(Beq^2 - 4*Aeq*Ceq)));    %citardauq formula
M = floor(LAM*ip);

%% BARRIER POINTS %%%%%%%%%%%%%%%
N = round(p*M);         % number of bridge points
dx = Lb/N;               % spatial resolution
x_bridge = (-0.5 + (1:N)')*dx; % barrier points
u_bridge = (4*hb/Lb^2)*x_bridge.*(x_bridge - Lb);

%% MODAL CONSTANTS %%%%%%%%%%%%
indm = ((1:M)');              % modal index
bet = (indm*(pi/L));        % wave numbers
k = 0.5*L*(EI*bet.^4 + T.*bet.^2);
r = rhoA*L*(eta0 + eta2*bet.^2);
sigm = (r./(2*m));
om0 = (sqrt(k/m));           % angular frequency
UPS = (exp(-sigm*dt));
gam = (sqrt(sigm.^2 - om0.^2));
OM = (cosh(dt*sqrt(sigm.^2 - om0.^2)));
AA = (2*OM.*UPS);
BB = (1 + UPS.^2);
CC = (0.25*xi*(AA + BB));
CCinv = 1./CC;
khat = ((4*m/dt^2)*(BB - AA)./(BB + AA));
rhat = ((2*m/dt)*(4 - 2*BB)./(BB + AA));

%% VECTORS & MATRICES %%%%%%%
hs = sparse(sin(bet*rs*L));
hsT = hs';
H = sparse(sin(bet*x_bridge'));
HT = H';
w = -sparse((EI*bet.^3 + (T*bet)).*((-1).^indm));
wT = w';
CH = sparse(diag(CC)*H);
Q = sparse(HT*CH);
I = speye(N);

%% INITIALISATION %%%%%%%%%%%%%%%%%
ut = (zeros(M,1));                % u tilde at time (n)
utm = (zeros(M,1));               % u tilde at time (n-1)
ui = -(4*hb*L)/(pi*Lb);           % initial displacement
ut(1) = ui;                       % first mode (t = 0)
C1 = ui;
C2 = ui*sigm(1);
utm(1) = exp(sigm(1)*dt)*(C1*cosh(-gam(1)*dt) + C2*sinh(-gam(1)*dt)/gam(1));
psimh = 0;      

%% OUTPUT VECTORS %%%%%%%%%%%%
output.Fstr = zeros(1,Ns);      % string force (at x = L)
output.us = zeros(1,Ns);        % string displacement (at x = rs*L)
output.vs = zeros(1,Ns);        % string velocity (at x = rs*L)
output.H = zeros(1,Ns);         % total energy (at t = (n+1/2)*dt)
output.Vc = zeros(1,Ns);        % contact pseudo-energy (at t = (n+1/2)*dt)
output.psi = zeros(1,Ns);       % placeholder, not applicable in this scheme

%% PLOT PREPARATION %%%%
if F_plot == 1
    Na = 100;
    xa = (1:Na)*(L/Na);     % string animation points
    Ha = sparse(sin(bet*xa));
    HaT = Ha.';
    umax = 1000*0.0025;
    figure(1);
    clf;
    grid;
    axis([0 L -umax umax]);
    set(gca,'Box','on');
    set(gca,'Layer','top')
end

%% LET THE COMMAND WINDOW KNOW WHAT'S HAPPENING
fprintf(1,'\n EXP-0-ME (OF = %d)',OF);

%% TIME-STEPPING LOOP %%%%
EPS = eps;
EPS2 = eps^2;
tic;
for n=1:Ns

    %plot string state
    if F_plot
        figure(1);
        us = hsT*ut;    
        hh = area([0; x_bridge; Lb],1000*[0; u_bridge; 0],'LineStyle','none','FaceColor',[0.85 0.3 0.2]);
        hold on;
        ua = HaT*ut;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(xa,1000*ua,'b.-');
        plot(rs*L,1000*us,'ro');
        hold off;
        axis([0 L -umax umax]);
        drawnow;
        pause(0.0001);
        %pause;
    end


    %calculate history varables
    zt = 0.5*(BB.*utm - AA.*ut);
    y = HT*ut - u_bridge;            % this is a costly line, as HT is dense
    Phi = (K/(alp+1))*max(0,y).^(alp+1);  % contact potential density 
    Vc = dx*sum(Phi) + V0;
    
    %calculate gradient vector
    g = ((K*dx)/sqrt(2*Vc))*max(0,y).^alp;
    if psimh < 0
        g = -g;
    end
    
    %calculate step vector
    gt = H*g;                   % this is a costly line, as H is dense
    gtT = gt.';
    ht = CC.*gt;
    htT = ht.';
    den = (1 + 0.25*gtT*ht);
    temp = -psimh*gt - 2*CCinv.*zt;
    coef = (0.25/den)*htT*temp;
    st = CC.*temp - coef*ht;
    
    %update variables
    psiph = psimh + 0.5*gtT*st;
    utp = st + utm;
    
    %record signals
    output.Fstr = wT*ut;
    if F_record
        us = hsT*ut;
        output.us(n) = us;
        f = -0.5*(psiph + psimh)*g;
        vs = hsT*(utp - utm)/(2*dt);   
        output.vs(n) = vs;
        duth = (utp - ut)/dt;
        utph = (utp + ut)/2;
        Vcph = 0.5*psiph^2;      
        Hph = 0.5*m*duth'*duth + 0.5*utph'*diag(khat)*utph + Vcph;
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
        output.psi(n) = psiph;
    end

    %must remember this
    utm = ut;
    ut = utp; 
    psimh = psiph;
end
TIM = toc;

%% REPORT RTF %%%%%%%%%%%%%%%%%
fprintf(1,' RTF = %f',TIM/par.dur);
