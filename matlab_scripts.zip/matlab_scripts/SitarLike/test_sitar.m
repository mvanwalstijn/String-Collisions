% test a scheme for sitar-like case study
clear;

%% SCHEME CHOICE %%%%%%%
% modal expansion options: 'IMP-1-ME', 'IMP-2-ME', 'EXP-0-ME','EXP-3-ME',' LI-4-ME'
% finite difference options: 'IMP-1-FD', 'IMP-2-FD', 'EXP-0-FD', 'EXP-3-FD',' LI-4-FD'
scheme = 'EXP-3-ME';           
%scheme = 'IMP-2-FD';           
%scheme = ' LI-4-FD';           % note the space at the start
%scheme = 'IMP-2-FD';           

%% SYSTEM PARAMETERS %%%%
par = parSitar;      % reads script to load physical parameters
Fs = 44100;         % base rate
LAM = 0.9;          % bandwidth factor for FD schemes (does not apply to ME schemes)
p = 0.1;            % factor to determine the number of barrier points

%% OVERSAMPLING FACTORS TO BE TESTED
OF = [1 4];

%% VARIABLE CHOICE %%%%%%%
var = 3;
% options: 
% 1 = mid-point displacement
% 2 = mid-point velocity 
% 3 = string force at x = L  <- only this option give representive RTFs (F_record = 1)
% 4 = contact potential
% 5 = system energy
% 6 = auxiliary variable <- gets recorded only for explicit schemes

%% TO RECORD OR NOT TO RECORD (THAT IS THE QUESTION) %%%%%%%
F_anim = 0;     % se to 1 to animate string motion
F_record = 1;       %F_record must be one for variables other than vs
if var == 3
    F_record = 0;   % not recording all variables, so we have representative RTFs 
end

%% SIMULATIONS %%%%%%%%%%%%%%
Ns = ceil(par.dur*Fs)+1;        % total number of samples
tt = (0:(Ns-1))*(1/Fs);
figure(3);
clf;
ax1 = subplot(2,1,1);
box on;
grid;
xlim([0 1000*par.dur]);
hold on;
title([scheme ' (full bandwidth)']);
ax2 = subplot(2,1,2);
box on;
grid;
xlim([0 1000*par.dur]);
xlabel('time (ms)');
title([scheme ' (decimated)']);
hold on;
if var == 1
    axes(ax1); ylabel('displacement (m)');
    axes(ax2); ylabel('displacement (m)');
elseif var == 2
    axes(ax1); ylabel('velocity (m/s)');
    axes(ax2); ylabel('velocity (m/s)');
elseif var == 3
    axes(ax1); ylabel('string force (N)');
    axes(ax2); ylabel('string force (N)');
elseif var == 4
    axes(ax1); ylabel('contact potential (J)');
    axes(ax2); ylabel('contact potential (J)');
elseif var == 5
    axes(ax1); ylabel('energy (J)');
    axes(ax2); ylabel('energy (J)');
elseif var == 6
    axes(ax1); ylabel('\psi');
    axes(ax2); ylabel('\psi');
end
for k=1:length(OF)
    if scheme == 'IMP-1-ME'
        [outp,t,dt,tau] = scheme_IMP_1_ME(par,OF(k)*Fs,p,LAM,F_record,F_anim);                                  
    elseif scheme == 'IMP-2-ME'
        [outp,t,dt,tau] = scheme_IMP_2_ME(par,OF(k)*Fs,p,LAM,F_record,F_anim);                                  
    elseif scheme == 'EXP-0-ME'
        [outp,t,dt,tau] = scheme_EXP_0_ME(par,OF(k)*Fs,p,LAM,F_record,F_anim);
    elseif scheme == 'EXP-3-ME'
        [outp,t,dt,tau] = scheme_EXP_3_ME(par,OF(k)*Fs,p,LAM,F_record,F_anim);
    elseif scheme == ' LI-4-ME'
        [outp,t,dt,tau] = scheme_LI_4_ME(par,OF(k)*Fs,p,LAM,F_record,F_anim); 
    elseif scheme == 'IMP-1-FD'
        [outp,t,dt,tau] = scheme_IMP_1_FD(par,OF(k)*Fs,p,LAM,F_record,F_anim);
    elseif scheme == 'IMP-2-FD'
        [outp,t,dt,tau] = scheme_IMP_2_FD(par,OF(k)*Fs,p,LAM,F_record,F_anim); 
    elseif scheme == 'EXP-0-FD'
        [outp,t,dt,tau] = scheme_EXP_0_FD(par,OF(k)*Fs,p,LAM,F_record,F_anim); 
    elseif scheme == 'EXP-3-FD'
        [outp,t,dt,tau] = scheme_EXP_3_FD(par,OF(k)*Fs,p,LAM,F_record,F_anim);
    elseif scheme == ' LI-4-FD'
        [outp,t,dt,tau] = scheme_LI_4_FD(par,OF(k)*Fs,p,LAM,F_record,0);
    end

    axes(ax1);    
    if var == 1
        hleg1(k) = plot(1000*t,outp.us,'-');
        sigD = decimate(outp.us,OF(k),35,'fir');
    elseif var == 2
        hleg1(k) = plot(1000*t,outp.vs,'-');
        sigD = decimate(outp.vs,OF(k),35,'fir');
    elseif var == 3
        hleg1(k) = plot(1000*t,outp.Fstr,'-');
        sigD = decimate(outp.Fstr,OF(k),35,'fir');
    elseif var == 4
        hleg1(k) = plot(1000*t,outp.Vc,'-');
        sigD = decimate(outp.Vc,OF(k),35,'fir');
    elseif var == 5
        hleg1(k) = plot(1000*t,outp.H,'-');
        sigD = decimate(outp.H,OF(k),35,'fir');
   elseif var == 6
        hleg1(k) = plot(1000*t,outp.psi,'.-');
        sigD = decimate(outp.psi,OF(k),35,'fir');
    end
    drawnow;
    LEG1{k}=strcat('OF = ',num2str(OF(k)));
    tD = (0:length(sigD)-1)*(1/Fs);
    axes(ax2);    
    hleg2(k) = plot(1000*tD,sigD,'-');
    drawnow;
    LEG2{k}=strcat('OF = ',num2str(OF(k)));
end
axes(ax1);
legend(hleg1,LEG1);
xlim([0 1000*par.dur]);
axes(ax2);    
legend(hleg2,LEG2);
xlim([0 1000*par.dur]);

