function[par] = parSitar
%parameters for an stiff string with damping and curved barrier
% Maarten van Walstijn 2023

%% TIME CONSTANTS %%%%%%
par.dur = 1;              % duration

%% PHYSICAL PARAMETERS %%%%%%%%%%
% phosphor bronze constants (C2# string)
r = 0.00035;
f1 = 69.3;
rho = 8800;
E = 110e9;
A = pi*r^2;
I = 0.25*pi*r^4;
L = 0.88;
T = 4*rho*A*f1^2*L^2;

par.L = L;            % string length
par.rhoA = rho*A;       % string mass per unit length
par.T = T;            % string tension
par.EI = E*I;            % string stiffness
par.eta0 = 0.5;         % freq-independent damping
par.eta2 = 0.002;       % freq-dependent damping
par.K = 1e9;           % contact law stiffness coeffient (1e9)
par.alp = 1.01;         % contact law exponent
par.Lb = 0.025;         % barrier length
par.hb = 5e-5;          % barrier height
par.rs = 0.5;          % relative position along string for monitoring u
                        

