% scheme LI-4-FD (sitar-like with FD)
% 'b' indicated 'bar' in the below (e.g. ub = '\bar{u}')
% Maarten van Walstijn 2023
function[output,t,dt,TIM] = scheme_LI_4_FD(par,Fs,p,LAM,F_record,F_plot)

V0 = eps;           % the energy gauge need not be more than the machine epsilon
OF = Fs/44100;      % the oversampling factor (w.r.t. 44.1 kHz)

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;        % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;          % string length
rhoA = par.rhoA;    % string mass per unit length
T = par.T;          % there will be tension
K = par.K;          % contact stiffness constant
alp = par.alp;      % contact power law exponent
rs = par.rs;        % relative position along the string for monitoring
EI = par.EI;        % stiffness parameter
eta0 = par.eta0;    % damping parameter (freq indep)
eta2 = par.eta2;    % damping parameter (freq dep)
h_bridge = par.hb;  % bridge height
L_bridge = par.Lb;  % bridge length

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);    % the string's fundamental frequency
om1 = 2*pi*f1;              % angular

%% FD GRID CONSTANTS %%%%%%%%%
TT = (T*dt^2)/rhoA + 4*eta2*dt;
dxbmin = sqrt(0.5*(TT + sqrt(TT^2 + (16*EI*dt^2)/rhoA)));
Mb = floor(LAM*L/dxbmin);    % number of string segments
dxb = L/Mb;                 % string node spacing
Nb = Mb - 1;                % number of string nodes
xb = (1:Nb)*dxb;            % string node vector

%% BRIDGE POINTS %%%%
N = round(p*Nb);                % number of bridge points
dx = L_bridge/N;                % spatial resolution
x_bridge = (-0.5 + (1:N)')*dx;  % bridge point vector
u_bridge = (4*h_bridge/L_bridge^2)*x_bridge.*(x_bridge - L_bridge);

%% FD COEFFICIENTS & MATRICES
lam = sqrt(T/rhoA)*dt/dxb;
chi = sqrt(EI/rhoA)*dt/(dxb^2);
zet0 = eta0*dt;
zet2 = eta2*dt/(dxb^2);
xi = (dt^2)/(rhoA);
Ib = speye(Nb);
D2 = sparse(toeplitz([-2 1 zeros(1,Nb-2)]));
D4 = D2*D2;
A = (2*Ib + (lam^2 + 2*zet2)*D2 - chi^2*D4)/(zet0 + 1);
B = (2*Ib + 2*zet2*D2)/(zet0 + 1);
C = (1/dxb)*(xi/(1 + zet0));
Hb = make_interpolant_order3(xb/L,x_bridge/L);
HbT = Hb.';
I = speye(Nb);
hout = make_interpolant_order3(xb/L,rs);

%% INITIALISATION %%%%%%%%%%%%%%%%%
ui = -(4*h_bridge*L)/(pi*L_bridge);           % initial displacement amplitude
ub = ui*sin(pi*xb/L)';       % ub = displacement at time (n)
ubm = ub*cos(-om1*dt);      % ubm = displacement at time (n-1)
psimh = zeros(N,1);

%% OUTPUT VECTORS %%%%%%%%%%%%
output.us = zeros(1,Ns);    % string displacement at x = rs*L
output.vs = zeros(1,Ns);    % string velocity at x = rs*L
output.Fstr = zeros(1,Ns);  % string force on end at x = L
output.Vc = zeros(1,Ns);    % the contact potential at time instants (n+1/2)
output.H = zeros(1,Ns);     % the pseudo-energy at time instants (n+1/2)
output.psi = zeros(1,Ns);   % placeholder, not applicable in this scheme

%% PLOT PREPARATION %%%%
if F_plot == 1
    umax = 1000*0.0025;     % plotted in mm, max value
    figure(1);
    clf;
    grid;
    axis([0 L -umax umax]);
    set(gca,'Box','on');
    set(gca,'Layer','top')
end

%% LET THE COMMAND WINDOW KNOW WHAT'S HAPPENING
fprintf(1,'\n LI-4-FD (OF = %d)',OF);

%% TIME-STEPPING LOOP %%%%
maxiter = 100;
tol = eps^2;
s = 300*eps*ones(N,1);
EPS = eps;
EPS2 = eps^2;
tic;
for n=1:Ns
    %plot string state
    if F_plot
        figure(1);
        us = hout*ub;
        hh = area([0; x_bridge; L_bridge],1000*[0; u_bridge; 0],'LineStyle','none','FaceColor',[0.85 0.3 0.2]);
        hold on;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(xb,1000*ub,'b.-');
        plot(x_bridge,1000*Hb*ub,'g.');
        plot(rs*L,1000*us,'ro');
        hold off;
        axis([0 L -umax umax]);
        drawnow;
        pause(0.0001);
    end
    %calculate required variables
    zb = 0.5*(B*ubm - A*ub);
    z = Hb*zb;
    y = Hb*ub - u_bridge;
    
    
    %calculate gradient vector
    sz = tanh(z/EPS); 
    g = sz.*psimh./(abs(z)+EPS);                    % g for no contact  
    indc = find(y > 0);    
    g(indc) = sqrt(0.5*K*(alp+1)*y(indc).^(alp-1));    % theory value of g       
    indg = find(psimh < 0 & y > 0);
    g(indg) = -g(indg);
        
    %calculate step vector
    G = spdiags(g,0,N,N);
    Q = HbT*G;
    QT = Q.';
    W = I + 0.25*dx*C*(Q*QT);
    sb = W\(-2*zb - dx*C*Q*psimh);    
        
    %update variables
    psiph = psimh + 0.5*QT*sb;    
    ubp = sb + ubm;
           
    %record force signal
    output.Fstr(n) = (EI/dxb^3)*(2*ub(Nb) - ub(Nb-1)) + (T/dxb)*ub(Nb);
    if F_record
        us = hout*ub;
        vs = hout*(ubp - ubm)/(2*dt);
        output.vs(n) = vs;
        f = -0.5*dx*(psiph + psimh).*g;
        Vcph = 0.5*dx*sum(psiph.^2);
        dub = (ub(2:N) - ub(1:(N-1)))/dxb;
        dubp = (ubp(2:N) - ubp(1:(N-1)))/dxb;
        Veta = -0.5*dxb*eta2*rhoA*(dubp - dub)'*(dubp - dub)/dt;
        Hph = dxb*( 0.5*EI*ubp'*(D4/dxb^4)*ub - 0.5*T*ubp'*(D2/dxb^2)*ub + ...
                0.5*(rhoA/dt^2)*(ubp - ub)'*(ubp -ub)) + Vcph + Veta;
        output.us(n) = us;
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
    end
        
    %must remember this
    ubm = ub;
    ub = ubp; 
    psimh = psiph;
end
TIM = toc;

%% REPORT RTF %%%%%%%%%%%%%%%%%
fprintf(1,' RTF = %f',TIM/par.dur);

