function[par] = parC2
%parameters for C2 string (Chaigne & Askenfelt 1994)
% Maarten van Walstijn 2023

%% TIME CONSTANTS %%%%%%
par.dur = 0.00225;              % duration

%% PHYSICAL PARAMETERS %%%%%%%%%%
par.L = 1.9;            % string length
par.rhoA = (35.0e-3)/par.L;      % string mass per unit length
par.T = 750;               % string tension
par.EI =  (7.5e-6)*par.T*par.L*par.L;        % string stiffness
par.eta0 = 0.5;        % string damping constant
par.eta2 = 1.0e-4;     % string damping constant
par.mh = 4.9e-3;        % hammer mass
par.re = 0.12;          % hammer relative striking position
par.kap = 4.0e8;         % contact law stiffness coeffient
par.alp = 2.3;          % contact law exponent

%% INITIAL VALUES %%%%
par.uhi = 0.0001;       % initial hammer displacement 
par.vhi = -2.5;            % initial hammer velocity 

