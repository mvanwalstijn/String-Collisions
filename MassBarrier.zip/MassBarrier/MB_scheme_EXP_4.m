function[output,t,dt] = scheme_EXP_4(par,Fs)
% Explicit Scheme for Mass-Barrier Collision (scheme EXP-4)
% Maarten van Walstijn 2023

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;         % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
m = par.m;              % mass
f0 = par.f0;            % oscillator frequency
sigm = par.sigm;        % attenuation constant
alp = par.alp;          % collision exponent
kap = par.kap;          % collision stiffness
ub = par.ub;            % barrier position

%% INITIAL VALUES %%%%%%%%%%%%%%%%%
ui = par.ui;                % initial displacement 
vi = par.vi;                % initial velocity 

%% CONVENIENT CONSTANTS %%%%%%
om0 = 2*pi*f0;           % angular frequency
gam = sqrt(sigm^2 - om0^2);
UPS = exp(-sigm*dt);
OM = cosh(gam*dt);
xi = (dt^2)/m;
AA = 2*OM*UPS;
BB = 1 + UPS^2;
CC = 0.25*xi*(AA + BB);
q = CC;
khat = (4*m/dt^2)*(BB - AA)/(BB + AA);
rhat = (2*m/dt)*(4 - 2*BB)/(BB + AA);

%% INITIALISATION %%%%%%%%%%%%
u = ui;            % u at time (n) 
if abs(gam) < 1e-15
    um = (1/UPS)*(ui - (vi+sigm*ui)*dt); 
else
    um = (1/UPS)*(ui*cosh(gam*dt) - (vi+sigm*ui)*(sinh(gam*dt))/gam);
end
psimh = 0;

%% OUTPUT VECTORS %%%%%%%%%%%%
output.u = zeros(1,Ns);
output.H = zeros(1,Ns);
output.Vc = zeros(1,Ns);
output.Fc = zeros(1,Ns);
output.g = zeros(1,Ns);
output.psi = zeros(1,Ns);
output.v = zeros(1,Ns);

%% SAMPLE LOOP %%%%%
EPSIL = eps;

for n=1:Ns    
    z = 0.5*(BB*um - AA*u);         % 'history' value
    y = u - ub;                     % current contact variable
    ym = um - ub;                   % previous contact variable
    
    sz = tanh(z/EPSIL);
    g = sz*psimh/(abs(z)+EPSIL);      % g for no contact    
    if y >= 0 & kap > 0 
        g = sqrt(0.5*kap*(alp+1)*y^(alp-1));    % theory value of g   
        if psimh < 0
            g = -g;
        end
    end
   
    
    %update equations
    s = -(2*z + q*g*psimh)/(1 + 0.25*q*g^2);
    up = s + um;
    psiph = psimh + 0.5*g*s;
        
    % compute force & energies
    Fc = -0.5*(psiph+psimh)*g;  % contact force
    Vcph = 0.5*psiph^2;
    Hph = 0.5*m*((up-u)/dt)^2 + 0.5*khat*((up+u)/2)^2 + Vcph;
            
    % monitor signals
    output.Fc(n) = Fc;
    output.u(n) = u;
    output.H(n) = Hph;
    output.Vc(n) = Vcph;
    output.psi(n) = psimh;
    output.g(n) = g;
    output.v(n) = (up - um)/(2*dt);
        
    % memorise
    um = u;
    u = up;
    psimh = psiph;
end

