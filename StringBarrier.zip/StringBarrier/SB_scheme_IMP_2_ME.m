% scheme IMP-2-ME (string-barrier)
% Maarten van Walstijn 2023
function[output,t,dt,TIM] = scheme_IMP_2_ME(par,Fs,F_record,F_plot)

OF = Fs/44100;      % the oversampling factor (w.r.t. 44.1 kHz)
LAM = 1/sqrt(OF);   % the bandwidth factor set so that we have O(N) operations/time step

%% TIME CONSTANTS %%%%%%
dur = par.dur;              % duration
dt = 1/Fs;                  % time step
Ns = ceil(dur*Fs)+1;        % total samples
t = (0:(Ns-1))*dt;          % time vector

%% PHYSICAL PARAMETERS %%%%%%%%%%
L = par.L;          % string length
rhoA = par.rhoA;    % string mass per unit length
T = par.T;          % there will be tension
K = par.K;          % contact stiffness constant
alp = par.alp;      % contact power law exponent
ubo = par.ubo;      % barrier level
rs = par.rs;        % relative position along the string for monitoring

%% NON-APPLICABLE PARAMETERS %%%%%
EI = 0;
eta0 = 0;  
eta2 = 0;

%% INITIAL VALUES %%%%
ui = par.ui;        % initial state

%% CONVENIENT CONSTANTS %%%%%%
f1 = sqrt(T/rhoA)/(2*L);    % fundamental frequency
om1 = 2*pi*f1;              % angular
Binh = (EI*pi^2)/(T*L^2);
m = (rhoA*L)/2;             % modal mass
xi = (dt^2)/m;              % input scalar

%% NUMBER OF MODES %%%%%%%%%%%%
M = floor((LAM/dt)*sqrt(2*m*L/T));

%% BARRIER POINTS %%%%%%%%%%%%%%%
N = M;                      % number of points equals number of modes
dx = L/N;                   % spatial resolution
xb = (-0.5 + (1:N))*dx;     % barrier points

%% MODAL CONSTANTS %%%%%%%%%%%%
indm = ((1:M)');              % modal index
bet = (indm*(pi/L));        % wave numbers
k = 0.5*L*(EI*bet.^4 + T.*bet.^2);
r = rhoA*L*(eta0 + eta2*bet.^2);
sigm = (r./(2*m));
om0 = (sqrt(k/m));           % angular frequency
UPS = (exp(-sigm*dt));
gam = (sqrt(sigm.^2 - om0.^2));
OM = (cosh(dt*sqrt(sigm.^2 - om0.^2)));
AA = (2*OM.*UPS);
BB = (1 + UPS.^2);
CC = (0.25*xi*(AA + BB));
khat = ((4*m/dt^2)*(BB - AA)./(BB + AA));
rhat = ((2*m/dt)*(4 - 2*BB)./(BB + AA));

%% VECTORS & MATRICES %%%%%%%
hs = sparse(sin(bet*rs*L));
hsT = hs';
H = sparse(sin(bet*xb));
HT = H';
w = -sparse((EI*bet.^3 + (T*bet)).*((-1).^indm));
wT = w';
CH = sparse(diag(CC)*H);
Q = sparse(HT*CH);
I = speye(N);

%% INITIALISATION %%%%%%%%%%%%%%%%%
ut = (zeros(M,1));                % u tilde at time (n)
utm = (zeros(M,1));               % u tilde at time (n-1)
ut(1) = ui;                     % first mode (t = 0)
utm(1) = ui*cosh(-gam(1)*dt);   % first mode (t = -dt)
Phimh = (zeros(N,1));       % contact potential density at time (n=1/2)
ym = zeros(N,1);

%% OUTPUT VECTORS %%%%%%%%%%%%
output.Fstr = zeros(1,Ns);      % string force (at x = L)
output.us = zeros(1,Ns);        % string displacement (at x = rs*L)
output.vs = zeros(1,Ns);        % string velocity (at x = rs*L)
output.H = zeros(1,Ns);         % total energy (at t = (n+1/2)*dt)
output.Vc = zeros(1,Ns);        % contact pseudo-energy (at t = (n+1/2)*dt)
output.psi = zeros(1,Ns);       % placeholder, not applicable in this scheme

%% PLOT PREPARATION %%%%
if F_plot == 1
    umax = 1000*0.0025;
    figure(1);
    clf;
    grid;
    axis([0 L -umax umax]);
    set(gca,'Box','on');
    set(gca,'Layer','top')
end

%% LET THE COMMAND WINDOW KNOW WHAT'S HAPPENING
fprintf(1,'\n IMP-2-ME (OF = %d)',OF);

%% TIME-STEPPING LOOP %%%%
maxiter = 100;
tol = eps^2;
s = 300*eps*ones(N,1);
EPS = eps;
EPS2 = eps^2;
tic;
for n=1:Ns
    %plot string state
    if F_plot
        figure(1);
        us = hsT*ut;
        hh = area([0 L],3000*[ubo ubo],1000*ubo,'LineStyle','none','FaceColor',0.9*[1 1 1]);
        hold on;
        uu = HT*ut;
        plot([0 L],[0 0],'k:');
        hold on;
        plot(xb,1000*uu,'b.-');
        plot(rs*L,1000*us,'ro');
        hold off;
        axis([0 L -umax umax]);
        pause(0.0001);
        %pause;
    end

    
    %calculate history varables
    zt = 0.5*(BB.*utm - AA.*ut);
    z = HT*zt;
    y = HT*ut - ubo;
    ystar = 0.5*(y + ym);  
    Phimh = (K/(alp+1))*max(0,ystar).^(alp+1);  % contact potential density
    dPhimh = K*max(0,ystar).^alp;
    ddPhimh = K*alp*max(0,ystar).^(alp-1);
    
    %solve nonlinear vector equation
    sdiff = 1;
    iter = 0;
    while sdiff > tol & iter < maxiter        
        Phiph = (K/(alp+1))*max(0,0.5*s+ystar).^(alp+1);
        dPhiph = K*max(0,0.5*s+ystar).^alp;        
        f = -2*dx*(((Phiph - Phimh).*s)./(s.^2 + EPS2) + 0.5*dPhimh.*(EPS2./(s.^2 + EPS2)));
        df = -2*dx*((0.5*dPhiph.*s - Phiph + Phimh)./(s.^2 + EPS2) + (EPS2./(s.^2 + EPS2)).*(0.125*ddPhimh));
        P = spdiags(-df,0,N,N);        
        F = s - Q*f + 2*z;
        J = I + Q*P;
        snew = s - J\F;
        sdiff = (snew - s)'*(snew - s);
        s = snew;
        iter = iter + 1;
    end
    if iter >= maxiter
        disp('IMP-2-ME: maxiter reached!');
    end
    
    %update variables
    Phiph = (K/(alp+1))*max(0,0.5*s+ystar).^(alp+1);
    f = -2*dx*(((Phiph - Phimh).*s)./(s.^2 + EPS2) + 0.5*dPhimh.*(EPS2./(s.^2 + EPS2)));
    utp = utm + CH*f - 2*zt;
         
    
    %record signals    
    vs = hsT*(utp - utm)/(2*dt);
    output.vs(n) = vs;
    if F_record == 1
        us = hsT*ut;
        output.us(n) = us;
        Fstr = wT*ut;
        output.Fstr(n) = Fstr;
        %energy update
        duth = (utp - ut)/dt;
        utph = (utp + ut)/2;
        Vcph = dx*sum(Phiph);
        Hph = 0.5*m*duth'*duth + 0.5*utph'*diag(khat)*utph + Vcph;
        output.H(n) = Hph;
        output.Vc(n) = Vcph;
    end

    %must remember this
    utm = ut;
    ut = utp; 
    ym = y;
end
TIM = toc;

%% REPORT RTF %%%%%%%%%%%%%%%%%
fprintf(1,' RTF = %f',TIM/par.dur);

