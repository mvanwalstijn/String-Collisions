function[par] = parStringBarrier
%parameters for an ideal string
% Maarten van Walstijn 2023

%% TIME CONSTANTS %%%%%%
par.dur = 1.0*0.0133;              % duration

%% PHYSICAL PARAMETERS %%%%%%%%%%
par.L = 0.5;            % string length
par.rhoA = 0.005;       % string mass per unit length
par.T = 250;            % string tension
par.K = 1e9;           % contact law stiffness coeffient
par.alp = 1.01;         % contact law exponent
par.ubo = 0.001;        % offset barrier position
par.rs = 0.5;           % relative string monitoring position

%% INITIAL VALUES %%%%
par.ui = -0.002;        % initial mid-string string displacement

